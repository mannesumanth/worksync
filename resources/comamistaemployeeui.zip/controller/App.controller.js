sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.amista.employeeui.controller.App",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map